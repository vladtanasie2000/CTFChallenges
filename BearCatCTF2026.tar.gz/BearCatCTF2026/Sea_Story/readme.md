Desc:
Nate

I created a pirate story simulator

Executable descripion:
The executable when ran offers us 4 options, with each option we are tasked with providing a name. At the end of execution a pharase along with our name is printed

Solution:
Analyzing the program using Ghidra we can see the issue in the choice selection part of the program.
The errors stems from the condition 3 in the selection process. In all other cases the name buffer is being send first and then the function that needs to be called. However for the choiceSel==3 the program first sends the eatCoconut address and then the name buffer. 
`    if (choiceSel == 3) {
      handlePirate(eatCoconut,localBuffer);
      goto code_r0x0010158d;
    }`
This causes the program to try and print the address of the eatCoconut function and execute our code, which allows us to use a shellcode to execute /bin/sh.

The next problem is the alphaNum check. It checks if the name contains only numbers or letters.This check is based on two parameters, the buffer where the value is being checked and the size of the buffer (obtained via strlen buffer)

The issue with this checck is IF the buffer size is retured as 0, then the is_alphanum_string function returns 1, meaning that all characters are alphanumeric. 

We can achive this by sending a char sequence begining with '00`. In C, strings are null terminated, meaning that C considers the ending of a string to be at /00 byte. However, if we send a char sequence beginning with /00 of any size, strlen returns 0, thus bypassing the is_alphanum_string function. 

The last issue is that having an /00 at the beginning of the shellcode will break the shellcode. To prevent this , I opted to use /00/c0 at the beginning , which is a valid opcode for `ADD AL,AL`. While this does change the AL and in consequence the RAX register, the shellcode we provide immediatly sets `mov rax, 0x732f2f2f6e69622f` which overwrites the AL as well.
